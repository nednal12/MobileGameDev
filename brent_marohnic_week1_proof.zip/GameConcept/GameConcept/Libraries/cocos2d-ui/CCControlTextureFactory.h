//
//  CCControlTextureFactory.h
//  cocos2d-ui
//
//  Created by Viktor on 9/5/13.
//  Copyright (c) 2013 Apportable. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCControlTextureFactory : NSObject

@end
